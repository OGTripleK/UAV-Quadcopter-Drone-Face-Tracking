import cv2
import numpy as np
from djitellopy import tello
import time

drone = tello.Tello()

w, h = 360, 240
fbRange = [6500,7000]
p_Xerror = 0.0
p_Yerror = 0.0
p_Zerror = 0.0
Xerror = 0.0
Yerror = 0.0
Zerror = 0.0
LRspeed, FBspeed, UDspeed , YAWspeed = 0.0,0.0,0.0,0.0



def findFace(img):
    faceCascade = cv2.CascadeClassifier(r"haarcascade_frontalface_default.xml")
    imgGray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    faces = faceCascade.detectMultiScale(imgGray, 1.2,8) #แก้เลขได้ ถ้าdetectไม่ดี

    myFaceListC = []
    myFaceListArea = []

    

    for (x,y,w,h) in faces:
        cv2.rectangle(img,(x,y),(x+w,y+h),(0,0,255),2)
        Cx = x+w // 2
        Cy = y+h // 2
        area = w*h
        
        cv2.circle(img,(Cx,Cy),5, (0,255,0,cv2.FILLED))
        myFaceListC.append([Cx,Cy])
        myFaceListArea.append(area)
    if len(myFaceListArea) != 0:
        i = myFaceListArea.index(max(myFaceListArea))
        return img, [myFaceListC[i],myFaceListArea[i]]
    else:
        return img,[[0,0],0]
    
def trackFace(info, w, h, Xerror, Yerror, Zerror, p_Xerror, p_Yerror, p_Zerror):
    global LRspeed
    
    UDpid = [0.08, 0.30, 0]#*2
    FBpid = [0.0026, 0.0030, 0]#*2
    YAWpid = [0.3, 0.2, 0]#OK
    
    area = info[1]
    x,y = info[0]
    FBspeed = 0

    Yerror = y-h//2
    Xerror = x-w//2
    Zerror = 0

    UDspeed = UDpid[0]*Yerror + UDpid[1]*(Yerror-p_Yerror)
    YAWspeed = YAWpid[0]*Xerror + YAWpid[1]*(Xerror-p_Xerror)
    

    if area > fbRange[0] and area < fbRange[1]:
        Zerror = 0
    if area > fbRange[1]:
        Zerror = fbRange[1]-area
    elif area < fbRange[0] and area !=0:
        Zerror = fbRange[0] - area
    
    FBspeed = FBpid[0]*Zerror + FBpid[1]*(Zerror-p_Zerror)
    
    if x==0:
        LRspeed, FBspeed, UDspeed , YAWspeed = 0,0,0,0

    
    UDspeed = int(np.clip(UDspeed, -50, 50))
    YAWspeed = int(np.clip(YAWspeed, -50, 50))
    FBspeed = int(np.clip(FBspeed, -50, 50))
    drone.send_rc_control(0, FBspeed, -UDspeed, YAWspeed)
    

    p_Xerror, p_Yerror, p_Zerror = Xerror, Yerror, Zerror
    
    return p_Xerror, p_Yerror, p_Zerror, Xerror, Yerror, Zerror


# while True:
#     img = drone.get_frame_read().frame
#     img = cv2.resize(img,(w,h))
#     img = cv2.circle(img,(180,120),5,(255,0,0,10))
#     img, info = findFace(img)
#     trackFace(info, w, h, Xerror, Yerror, Zerror, p_Xerror, p_Yerror, p_Zerror)
#     print("Center", info[0], "AreA", info[1])
    
#     cv2.imshow("Output", img)
#     if cv2.waitKey(1) & 0xFF == ord('e'):
#         drone.land()
#         break
