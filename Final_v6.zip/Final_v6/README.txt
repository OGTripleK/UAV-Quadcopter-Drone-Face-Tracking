Instruction on how to use this script.
1.) Run main.py
2.) After running, you will receive virus detected notification.
Note* : We use Keylogger.py as drone controller which grab every keyboard input. Windows defender thought that this is a virus and it is not (False Positive).
3.) To prevent windows from removing the keylogger, please add "Final_v6" folder into exclusion list.
- To do this go to Settings > Update & Security > Windows Security > Virus & threat protection