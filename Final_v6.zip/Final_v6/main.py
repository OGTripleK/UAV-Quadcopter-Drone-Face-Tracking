from concurrent.futures import thread
import cv2
import numpy as np
import random
import sys
import os
from time import sleep
import keylogger
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.uic import loadUi
from PyQt5.QtCore import pyqtSlot, QTimer, QDate, Qt, QThread
from PyQt5.QtWidgets import QDialog,QMessageBox, QProgressBar
from djitellopy import tello
import time
import threading
from FaceTrack import *


battery_rand = random.randrange(0,100,3)
input_keyboard = ''
drone = tello.Tello()
x = 0
y = 0
speed = 50
ModeSelected = ""
thread_end = False
pid_thread_end = False
Drone_onground = True
confirm_button_pressed = False
drone_tracking_mode = False
speed_radio = 0
drone.connect()
drone.streamon()



def drone_controller():
    global drone_tracking_mode
    global lr, fb, ud, rt
    global Drone_onground
    global speed
    lr, fb, ud, rt = 0,0,0,0
    global input_keyboard
    if ModeSelected == "Manual":
        if input_keyboard != keylogger.info: input_keyboard = keylogger.info
        else:
            input_keyboard = ''
            keylogger.info = ''
    else:
        input_keyboard = ''
    
    if input_keyboard == 'q': drone.takeoff()
    elif input_keyboard == 'e': drone.land()
    
    if input_keyboard == 'w': fb = speed
    elif input_keyboard == 's': fb = -speed

    if input_keyboard == 'a': lr = -speed
    elif input_keyboard == 'd': lr = speed

    if input_keyboard == 'Key.up': ud = speed
    elif input_keyboard == 'Key.down': ud = -speed

    if input_keyboard == 'Key.left': rt = -speed
    elif input_keyboard == 'Key.right': rt = speed

    
    if input_keyboard == 'r': cv2.imwrite(f'Captured/{time.time()}.jpg',Capture)

    if input_keyboard == 'z':
        global pid_thread_end
        if drone_tracking_mode == False:
            drone_tracking_mode = True
            auto_thread = threading.Thread(target=PID)
            auto_thread.start()
            Drone_onground = False
        else:
            pid_thread_end = True
            drone_tracking_mode = False
            Drone_onground = False


    return [lr, fb, ud, rt]



def main_controller():
    while True:
        dc = drone_controller()
        drone.send_rc_control(dc[0], dc[1], dc[2], dc[3])
        sleep(0.5)
        global thread_end
        global Drone_onground
        if drone_tracking_mode == False:
            if thread_end == True:
                thread_end = False
                Drone_onground = True
                break

def PID():
    drone.send_rc_control(0,0,15,0)
    sleep(1.3)
    drone.send_rc_control(0,0,0,0)
    while True:
        global Capture
        img = cv2.resize(Capture,(w,h))
        img = cv2.circle(img,(180,120),5,(255,0,0,10))
        global info
        img, info = findFace(img)
        trackFace(info, w, h, Xerror, Yerror, Zerror, p_Xerror, p_Yerror, p_Zerror)

        global pid_thread_end
        global Drone_onground
        if pid_thread_end == True:
            pid_thread_end = False
            Drone_onground = True
            break

def auto_main_controller():
    while True:
        dc = auto_only_controller()
        drone.send_rc_control(dc[0], dc[1], dc[2], dc[3])
        sleep(0.5)
        global thread_end
        global Drone_onground
        if drone_tracking_mode == False:
            if thread_end == True:
                thread_end = False
                Drone_onground = True
                break

def auto_only_controller():
    global drone_tracking_mode
    global lr, fb, ud, rt
    global Drone_onground
    global speed
    lr, fb, ud, rt = 0,0,0,0
    global input_keyboard
    if ModeSelected == "Auto":
        if input_keyboard != keylogger.info: input_keyboard = keylogger.info
        else:
            input_keyboard = ''
            keylogger.info = ''
    else:
        input_keyboard = ''
    if input_keyboard == 'q': drone.takeoff()
    elif input_keyboard == 'e': drone.land()
    if input_keyboard == 'Key.up': ud = speed
    elif input_keyboard == 'Key.down': ud = -speed
    if input_keyboard == 'Key.left': rt = -speed
    elif input_keyboard == 'Key.right': rt = speed
    if input_keyboard == 'r': cv2.imwrite(f'Captured/{time.time()}.jpg',Capture)
    return [lr, fb, ud, rt]


class Ui_MainWindow(QMainWindow):
    

    def __init__(self):
        super(Ui_MainWindow, self).__init__()
        loadUi(r'Final_v6\test.ui', self)
        global battery
        global temperature
        battery = drone.get_battery()
        self.batterybar.setValue(battery)
        temperature = int(drone.get_temperature())
        self.tempbar.setValue(temperature)
        self.connect_button.setEnabled(False)
        self.startdrone_button.setEnabled(False)
        self.awaitcheck = True
        
        # self.image = None
        self.Worker1 = Worker1()
        self.Worker1.start()
        self.Worker1.ImageUpdate.connect(self.ImageUpdateSlot)
            
        
    def ImageUpdateSlot(self, Image):
        if confirm_button_pressed == True:
            self.imglabel.setPixmap(QPixmap.fromImage(Image))
        global x
        global y
        global ModeSelected
        if x > 1500:
            self.update_bat()
            x = 0
            
        if y > 50:
            self.drone_info_update()
            self.safetycheck()
            self.controlmethod()
            self.speed_radio_option()
            y = 0
        x+=1
        y+=1
        
    

    def controlmethod(self):
        global ModeSelected
        global Drone_onground
        global confirm_button_pressed
        global thread_end
        global pid_thread_end
        global drone_tracking_mode

        if self.connect_button.isChecked():
            if Drone_onground == True:
                if self.manualcontrol_button.isChecked():
                    print("Manual Control")
                    ModeSelected = "Manual"
                    self.disable_button()
                    Drone_onground = False
                    confirm_button_pressed = True
                    mc_thread = threading.Thread(target=main_controller)
                    mc_thread.start()
                    
                else:
                    drone_tracking_mode = True
                    print("Auto Control")
                    ModeSelected = "Auto"
                    self.disable_button()
                    confirm_button_pressed = True
                    self.startdrone_button.setEnabled(True)
                    if self.startdrone_button.isChecked():
                        drone.takeoff()
                        auto_thread = threading.Thread(target=PID)
                        auto_thread.start()
                        auto_controller_thread = threading.Thread(target=auto_main_controller)
                        auto_controller_thread.start()
                        Drone_onground = False
            if Drone_onground == False:
                if ModeSelected == "Auto":
                    if self.startdrone_button.isChecked() == False:
                        try:
                            drone.land()
                            self.startdrone_button.setEnabled(False)
                            pid_thread_end = True
                        except:
                            self.startdrone_button.setEnabled(False)
                            pid_thread_end = True
        if self.connect_button.isChecked() == False:
            global input_keyboard
            Drone_onground = True
            self.enable_button()
            if ModeSelected == "Manual":
                thread_end = True
                drone_tracking_mode = False
                input_keyboard = ''
            if ModeSelected == "Auto":
                pid_thread_end = True
                thread_end = True
                drone_tracking_mode = False
                input_keyboard = ''
            drone_tracking_mode = False
            confirm_button_pressed = False
            ModeSelected = ""
            input_keyboard = ''
            self.startdrone_button.setEnabled(False)
    def speed_radio_option(self):
        global speed
        if self.speed50_radio.isChecked():
            speed = 50
        elif self.speed75_radio.isChecked():
            speed = 75
        else:
            speed = 100
        
        
    def safetycheck(self):
        if self.droneroom_check.isChecked() and self.standclear_check.isChecked():
            self.connect_button.setEnabled(True)
        else:
            self.connect_button.setEnabled(False)

    def drone_info_update(self):
        if self.connect_button.isChecked():
            self.roll_value.setText(str(drone.get_roll()))
            self.pitch_value.setText(str(drone.get_pitch()))
            self.yaw_value.setText(str(drone.get_yaw()))
            self.speedx_value.setText(str(drone.get_speed_x()))
            self.speedy_value.setText(str(drone.get_speed_y()))
            self.speedz_value.setText(str(drone.get_speed_z()))
            self.height_value.setText(str(drone.get_height()))
            self.barometer_value.setText(str(drone.get_barometer()))
            self.flighttime_value.setText(str(drone.get_flight_time()))
        else:
            self.roll_value.setText("-")
            self.pitch_value.setText("-")
            self.yaw_value.setText("-")
            self.speedx_value.setText("-")
            self.speedy_value.setText("-")
            self.speedz_value.setText("-")
            self.height_value.setText("-")
            self.barometer_value.setText("-")
            self.flighttime_value.setText("-")
    def update_bat(self):
        battery = drone.get_battery()
        temperature = int(drone.get_temperature())
        self.batterybar.setValue(battery)
        self.tempbar.setValue(temperature)

    def enable_button(self):
        self.autocontrol_button.setEnabled(True)
        self.manualcontrol_button.setEnabled(True)
        self.droneroom_check.setEnabled(True)
        self.standclear_check.setEnabled(True)

    def disable_button(self):
        self.autocontrol_button.setEnabled(False)
        self.manualcontrol_button.setEnabled(False)
        self.droneroom_check.setEnabled(False)
        self.standclear_check.setEnabled(False)
    

    

    
class Worker1(QThread):
    ImageUpdate = pyqtSignal(QImage)
    def run(self):
        self.ThreadActive = True
        
        while self.ThreadActive:
            global Capture
            global Pic
            global ConvertToQtFormat
            if drone_tracking_mode == False:
                Capture = drone.get_frame_read().frame
                Image = cv2.cvtColor(Capture, cv2.COLOR_BGR2RGB)
                ConvertToQtFormat = QImage(Image.data, Image.shape[1], Image.shape[0], QImage.Format_RGB888)
                Pic = ConvertToQtFormat.scaled(640, 480, Qt.KeepAspectRatio)
                self.ImageUpdate.emit(Pic)

            if drone_tracking_mode == True:
                Capture = drone.get_frame_read().frame
                img = cv2.cvtColor(Capture, cv2.COLOR_BGR2RGB)
                img = cv2.resize(img,(w,h))
                img = cv2.circle(img,(180,120),5,(255,0,0,10))
                global info
                img, info = findFace(img)
                ConvertToQtFormat = QImage(img.data, img.shape[1], img.shape[0], QImage.Format_RGB888)
                Pic = ConvertToQtFormat.scaled(640, 480, Qt.KeepAspectRatio)
                self.ImageUpdate.emit(Pic)
                


def random_bat():
    while True:
        global battery_rand
        battery_rand = random.randrange(0,100,3)


if True:
    # randx = threading.Thread(target=random_bat)
    # randx.start()
    App = QApplication(sys.argv)
    Root = Ui_MainWindow()
    Root.show()
    sys.exit(App.exec())